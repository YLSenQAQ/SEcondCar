package main

import (
	"fmt"
	//"strconv"
	"encoding/json"
	"github.com/xuperchain/xuperchain/core/contractsdk/go/code"
	"github.com/xuperchain/xuperchain/core/contractsdk/go/driver"
)

const DMV, InsuranceCompany, RepairShop, splitChar = "DMV", "InsuranceCompany", "RepairShop", "_"

type secondhand_car struct {}

type CarStruct struct {
	OriginalPrice float64		//	车辆原价
	SellingPrice float64		//	车辆报价
	SalePrice	float64		//	车辆成交价
	EngineNumber string			//发动机号
	Time int		//	上牌时间
	Mileage float64		//	里程数
	WheelBase string		//	轴距
	Manufacture int	// 车辆厂商
	GearboxType int		//	变速类型
	CarType int		//	汽车类型
	EmissionStandard int		//	排放标准
	MaxPs int		//	最大马力
	PowerSunroof bool		//	电动天窗，true代表有电动天窗，false代表没有
	PanoramicSunroof bool		//	全景天窗，true代表有全景天窗，false代表没有
	GPS bool		//	GPS导航，true代表有GPS导航，false代表没有
	ReversingRadar bool		//	倒车雷达，true代表有倒车雷达，false代表没有
	ReversingImageSystem bool		//	倒车影像系统，true代表有倒车影像系统，false代表没有
	LeatherSeat bool		//	真皮座椅，true代表有真皮座椅，false代表没有
	MajorMalfunction bool		//	重大事故，true代表有重大事故，false代表没有
	BubbleAndBurn bool		//	泡水火烧，true代表有泡水火烧，false代表没有
	SlightCollision bool		//	轻微碰撞，true代表有轻微碰撞，false代表没有
	PaintRepairTime int		//	漆面修复次数
	SheetmetalRepairTime int		//	钣金修复次数
	AppearancePartsReplacementTime int		//	外观件更换次数
	TransferTime int 		//过户次数
	DMVCarDescribe interface{}		//车管所详细描述
	RepairShopDescribe interface{}		//维修店详细描述
	InsuranceCompanyDescribe interface{}		//保险公司详细描述
}

func (e *secondhand_car) Initialize(ctx code.Context) code.Response {
	creator, ok := ctx.Args()["creator"]
	if !ok {
		return code.Errors("missing creator")
	}
	err := ctx.PutObject([]byte("creator"), creator)
	if err != nil {
		return code.Error(err)
	}

	return code.OK(nil)
}

func getByDepartment(ctx code.Context, VIN string, department string) map[string]interface{} {
	var key []byte

	switch department {
	case DMV:
		key = []byte(DMV + splitChar + VIN)
	case RepairShop:
		key = []byte(RepairShop + splitChar + VIN)
	case InsuranceCompany:
		key = []byte(InsuranceCompany + splitChar + VIN)
	}

	return getByKey(ctx, string(key))
}

func getByKey(ctx code.Context, key string) map[string]interface{} {
	value, _ := ctx.GetObject([]byte(key))
	map_value := convert_json_to_map(value)
	return map_value
}


func (e *secondhand_car) QueryCarByVIN(ctx code.Context) code.Response {
	VIN := string(ctx.Args()["VIN"])
	if VIN == "" {
		return code.Errors("Missing key: VIN")
	}

	key1 := DMV + splitChar + VIN
	key2 := RepairShop + splitChar + VIN
	key3 := InsuranceCompany + splitChar + VIN

	carByDMV := getByKey(ctx, key1)
	carByRepairShop := getByKey(ctx, key2)
	carByInsuranceCompany := getByKey(ctx, key3)
	car := &CarStruct{
		Time :carByDMV["Time"].(int),
		WheelBase :carByDMV["WheelBase"].(string),
		Manufacture :carByDMV["Manufacture"].(int),
		GearboxType :carByDMV["GearboxType"].(int),
		CarType :carByDMV["CarType"].(int),
		EmissionStandard :carByDMV["EmissionStandard"].(int),
		MaxPs :carByDMV["MaxPs"].(int),
		TransferTime :carByDMV["TransferTime"].(int),
		MajorMalfunction :carByDMV["MajorMalfunction"].(bool),
		BubbleAndBurn :carByDMV["BubbleAndBurn"].(bool),
		EngineNumber :carByDMV["EngineNumber"].(string),
		DMVCarDescribe :carByDMV["DMVCarDescribe"],
		Mileage :carByRepairShop["Mileage"].(float64),
		PowerSunroof :carByRepairShop["PowerSunroof"].(bool),
		PanoramicSunroof :carByRepairShop["PanoramicSunroof"].(bool),
		GPS :carByRepairShop["GPS"].(bool),
		ReversingRadar :carByRepairShop["ReversingRadar"].(bool),
		ReversingImageSystem :carByRepairShop["ReversingImageSystem"].(bool),
		LeatherSeat :carByRepairShop["LeatherSeat"].(bool),
		SlightCollision :carByRepairShop["SlightCollision"].(bool),
		PaintRepairTime :carByRepairShop["PaintRepairTime"].(int),
		SheetmetalRepairTime :carByRepairShop["SheetmetalRepairTime"].(int),
		AppearancePartsReplacementTime :carByRepairShop["AppearancePartsReplacementTime"].(int),
		RepairShopDescribe :carByRepairShop["RepairShopDescribe"],
		SellingPrice :carByInsuranceCompany["SellingPrice"].(float64),
		InsuranceCompanyDescribe :carByInsuranceCompany["InsuranceCompanyDescribe"],
	}
	result, _ := json.Marshal(&car)
	return code.OK(result)
}


func (e *secondhand_car) GetFromDepartment(ctx code.Context) code.Response {
	VIN := string(ctx.Args()["VIN"])
	if VIN == "" {
		return code.Errors("Missing key: VIN")
	}

	department := string(ctx.Args()["department"])
	if department == "" {
		return code.Errors("Missing key: department")
	}

	value := getByDepartment(ctx, VIN, department)

	return code.OK(convert_map_to_json(value))
}

func convert_map_to_json(my_map map[string]interface{}) []byte{
	b, err := json.Marshal(my_map)
	if err != nil {
		fmt.Printf("marshal failed, err:%v\n", err)
		return nil
	}
	return b
}

func convert_json_to_map(b []byte)map[string]interface{}{
	var m map[string]interface{}
	err := json.Unmarshal(b, &m)
	if err != nil {
		fmt.Printf("unmarshal failed, err:%v\n", err)
		return nil
	}
	return m
}

func main() {
	driver.Serve(new(secondhand_car))
}
