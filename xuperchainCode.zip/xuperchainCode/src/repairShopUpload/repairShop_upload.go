package main

import (
	"fmt"
	"strconv"
	"encoding/json"
	"github.com/xuperchain/xuperchain/core/contractsdk/go/code"
	"github.com/xuperchain/xuperchain/core/contractsdk/go/driver"
)

const RepairShop, RepairShopCarCounts = "RepairShop", "RepairShopCarCounts"

type CarStruct struct {
	Mileage float64		//	里程数
	PowerSunroof bool		//	电动天窗，true代表有电动天窗，false代表没有
	PanoramicSunroof bool		//	全景天窗，true代表有全景天窗，false代表没有
	GPS bool		//	GPS导航，true代表有GPS导航，false代表没有
	ReversingRadar bool		//	倒车雷达，true代表有倒车雷达，false代表没有
	ReversingImageSystem bool		//	倒车影像系统，true代表有倒车影像系统，false代表没有
	LeatherSeat bool		//	真皮座椅，true代表有真皮座椅，false代表没有
	SlightCollision bool		//	轻微碰撞，true代表有轻微碰撞，false代表没有
	PaintRepairTime int		//	漆面修复次数
	SheetmetalRepairTime int		//	钣金修复次数
	AppearancePartsReplacementTime int		//	外观件更换次数
	RepairShopDescribe interface{}
}

type secondhand_car struct {}

func (e *secondhand_car) Initialize(ctx code.Context) code.Response {
	creator, ok := ctx.Args()["creator"]
	if !ok {
		return code.Errors("missing creator")
	}
	err := ctx.PutObject([]byte("creator"), creator)
	if err != nil {
		return code.Error(err)
	}
	initializeStatisticsData(ctx)
	return code.OK(nil)
}

func initializeStatisticsData(ctx code.Context) {
	ctx.PutObject([]byte(RepairShopCarCounts), []byte("0"))
}

func updateStatisticsData(ctx code.Context, key string) bool {
	value, err := ctx.GetObject([]byte(key))
	cnt := 0
	if err == nil {
		cnt, _ = strconv.Atoi(string(value))
	}

	var cntstr string

	cntstr = strconv.Itoa(cnt + 1)

	err = ctx.PutObject([]byte(key), []byte(cntstr))
	if err != nil {
		return false
	}
	return true
}

func upload(ctx code.Context, department string) code.Response {
	var key []byte
	var ok bool

	VIN, ok := ctx.Args()["VIN"]
	if !ok {
		return code.Errors("missing VIN")
	}

	if department == RepairShop{
		b_value, ok := ctx.Args()["RepairShop_INFO"]
		if !ok {
			return code.Errors("missing RepairShop_INFO")
		}else{
			value := convert_json_to_map(b_value)
			if value["Mileage"] == nil{
				return code.Errors("missing Mileage")
			}else if value["PowerSunroof"] == nil{
				return code.Errors("missing PowerSunroof")
			}else if value["PanoramicSunroof"] == nil{
				return code.Errors("missing PanoramicSunroof")
			}else if value["GPS"] == nil{
				return code.Errors("missing GPS")
			}else if value["ReversingRadar"] == nil {
				return code.Errors("missing ReversingRadar")
			}else if value["ReversingImageSystem"] == nil {
				return code.Errors("missing ReversingImageSystem")
			}else if value["LeatherSeat"] == nil{
				return code.Errors("missing LeatherSeat")
			}else if value["SlightCollision"] == nil {
				return code.Errors("missing SlightCollision")
			}else if value["PaintRepairTime"] == nil{
				return code.Errors("missing PaintRepairTime")
			}else if value["SheetmetalRepairTime"] == nil {
				return code.Errors("missing SheetmetalRepairTime")
			}else if value["AppearancePartsReplacementTime"] == nil{
				return code.Errors("missing AppearancePartsReplacementTime")
			}else if value["RepairShopDescribe"] == nil{
				return code.Errors("missing RepairShopDescribe")
			}else{
				//car := &CarStruct{
				//	Mileage: value["Mileage"],
				//	PowerSunroof: value["PowerSunroof"],
				//	PanoramicSunroof: value["PanoramicSunroof"],
				//	GPS: value["GPS"],
				//	ReversingRadar: value["ReversingRadar"],
				//	ReversingImageSystem: value["ReversingImageSystem"],
				//	LeatherSeat: value["LeatherSeat"],
				//	SlightCollision: value["SlightCollision"],
				//	PaintRepairTime: value["PaintRepairTime"],
				//	SheetmetalRepairTime: value["SheetmetalRepairTime"],
				//	AppearancePartsReplacementTime: value["AppearancePartsReplacementTime"],
				//	RepairShopDescribe: value["RepairShopDescribe"],
				//}
				key = []byte("RepairShop_" + string(VIN))
			}
		}
		err := ctx.PutObject(key, b_value)
		if err != nil {
			return code.Error(err)
		}
		updateStatisticsData(ctx, RepairShopCarCounts)
		return code.OK(b_value)
	}else{
		return code.Errors("the department is not repairshop.")
	}
}

// 维修店数据上传
func (e *secondhand_car) UploadByRepairShop(ctx code.Context) code.Response {
	return upload(ctx, RepairShop)
}

func convert_json_to_map(b []byte)map[string]interface{}{
	var m map[string]interface{}
	err := json.Unmarshal(b, &m)
	if err != nil {
		fmt.Printf("unmarshal failed, err:%v\n", err)
		return nil
	}
	return m
}

func main() {
	driver.Serve(new(secondhand_car))
}

