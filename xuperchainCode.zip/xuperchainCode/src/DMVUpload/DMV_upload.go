package main

import (
	"fmt"
	"strconv"
	"encoding/json"
	"github.com/xuperchain/xuperchain/core/contractsdk/go/code"
	"github.com/xuperchain/xuperchain/core/contractsdk/go/driver"
)

const DMV, DMVCarCounts = "DMV", "DMVCarCounts"

const (
	StickShift = iota		//手动挡
	Automatic		//自动挡
	StickShiftAndAutomatic		//手自一体
)

const (
	MPV = iota		//MPV
	SUV			//SUV
	WingRooms		//两厢
	ThreeRooms		//三厢
)

const (
	Third = iota 		//国三及以下
	Forth		//国四
	Fifth		//国五及以上
)

type CarStruct struct {
	Time int		//	上牌时间
	WheelBase string		//	轴距
	Manufacture int	// 车辆厂商
	GearboxType int		//	变速类型
	CarType int		//	汽车类型
	EmissionStandard int		//	排放标准
	MaxPs int		//	最大马力
	TransferTime int 		//过户次数
	MajorMalfunction bool		//	重大事故，true代表有重大事故，false代表没有
	BubbleAndBurn bool		//	泡水火烧，true代表有泡水火烧，false代表没有
	EngineNumber string			//发动机号
	DMVDescribe interface{}		//详细描述
}

type secondhand_car struct {}

func (e *secondhand_car) Initialize(ctx code.Context) code.Response {
	creator, ok := ctx.Args()["creator"]
	if !ok {
		return code.Errors("missing creator")
	}
	err := ctx.PutObject([]byte("creator"), creator)
	if err != nil {
		return code.Error(err)
	}

	initializeStatisticsData(ctx)

	return code.OK(nil)
}

func initializeStatisticsData(ctx code.Context) {
	ctx.PutObject([]byte(DMVCarCounts), []byte("0"))
}

func updateStatisticsData(ctx code.Context, key string) bool {
	value, err := ctx.GetObject([]byte(key))
	cnt := 0
	if err == nil {
		cnt, _ = strconv.Atoi(string(value))
	}

	var cntstr string

	cntstr = strconv.Itoa(cnt + 1)

	err = ctx.PutObject([]byte(key), []byte(cntstr))
	if err != nil {
		return false
	}
	return true
}

func upload(ctx code.Context, department string) code.Response {
	var key []byte
	var ok bool

	VIN, ok := ctx.Args()["VIN"]
	if !ok {
		return code.Errors("missing VIN")
	}

	if department == DMV{
		b_value, ok := ctx.Args()["DMV_INFO"]
		if !ok {
			return code.Errors("missing DMV_INFO")
		}else{
			value := convert_json_to_map(b_value)
			if value["Time"] == nil{
				return code.Errors("missing Time")
			}else if value["WheelBase"] == nil{
				return code.Errors("missing WheelBase")
			}else if value["Manufacture"] == nil{
				return code.Errors("missing Manufacture")
			}else if value["GearboxType"] == nil{
				return code.Errors("missing GearboxType")
			}else if value["CarType"] == nil{
				return code.Errors("missing CarType")
			}else if value["EmissionStandard"] == nil{
				return code.Errors("missing EmissionStandard")
			}else if value["MaxPs"] == nil{
				return code.Errors("missing MaxPs")
			}else if value["TransferTime"] == nil{
				return code.Errors("missing TransferTime")
			}else if value["MajorMalfunction"] == nil{
				return code.Errors("missing MajorMalfunction")
			}else if value["BubbleAndBurn"] == nil{
				return code.Errors("missing BubbleAndBurn")
			}else if value["EngineNumber"] == nil{
				return code.Errors("missing EngineNumber")
			}else if value["DMVDescribe"] == nil{
				return code.Errors("missing DMVDescribe")
			}else{
				//car := &CarStruct{
				//	Time: value["Time"].(int),
				//	WheelBase: value["WheelBase"].(string),
				//	Manufacture: value["Manufacture"].(int),
				//	GearboxType: value["GearboxType"].(int),
				//	CarType: value["CarType"].(int),
				//	EmissionStandard: value["EmissionStandard"].(int),
				//	MaxPs: value["MaxPs"].(int),
				//	TransferTime: value["TransferTime"].(int),
				//	MajorMalfunction: value["MajorMalfunction"].(bool),
				//	BubbleAndBurn: value["BubbleAndBurn"].(bool),
				//	EngineNumber: value["EngineNumber"].(string),
				//	DMVDescribe: value["DMVDescribe"],
				//}
				key = []byte("DMV_" + string(VIN))
			}
		}
		err := ctx.PutObject(key, b_value)
		if err != nil {
			return code.Error(err)
		}
		updateStatisticsData(ctx, DMVCarCounts)
		return code.OK(b_value)
	}else{
		return code.Errors("the department is not DMV.")
	}
}

// 车管所数据上传
func (e *secondhand_car) UploadByDMV(ctx code.Context) code.Response {
	return upload(ctx, DMV)
}

func convert_json_to_map(b []byte)map[string]interface{}{
	var m map[string]interface{}
	err := json.Unmarshal(b, &m)
	if err != nil {
		fmt.Printf("unmarshal failed, err:%v\n", err)
		return nil
	}
	return m
}

func main() {
	driver.Serve(new(secondhand_car))
}

