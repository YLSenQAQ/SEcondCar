# 智能合约详细说明

## 智能合约代码结构设计

相关源码文件均存放在src文件夹下，具体目录的设计结构如下：

- DMVUpload文件夹下存放车管所上传数据的智能合约，DMV_upload.go即为该智能合约的源码文件。
- repairShopUpload文件夹下存放维修店上传数据的智能合约，repairShop_upload.go即为该智能合约的源码文件。
- insuranceCompanyUpload文件夹下存放保险公司上传数据的智能合约，insuranceCompany_upload.go即为该智能合约的源码文件。
- salePriceUpload文件夹下存放上传成交价数据的智能合约，salePrice_upload.go即为该智能合约的源码文件。
- enquire文件夹下存放查询二手车信息的智能合约，enquire.go即为该智能合约的源码文件。
- statistics文件夹下存放统计二手车数量的智能合约，statistics.go即为该智能合约的源码文件。

## 智能合约代码编制

本次项目依据功能需求总共设计了六个智能合约，智能合约采用的系统架构为百度超级链xuperchain，每个合约均采用go语言进行合约代码的编写。

## 智能合约使用

依照XuperChain官方部署文档下载代码并进行编译，编译完成后进入到output目录，代码样例如下：

```
cd output
```

在output目录下创建百度超级链并在后台启动xuperchain节点，代码样例如下：

```
./xchain-cli createChain
nohup ./xchain &
```

创建合约账号并往账号里转入充足的测试资源,代码样例如下：

```
./xchain-cli account new --account 0123456789123456 --fee 2000
./xchain-cli transfer --to XC0123456789123456@xuper --amount 100000000
```

将src文件夹放在output文件夹下，由于本项目已写好Makefile文件，因此进行智能合约的编译时只需进入智能合约源码文件夹，在src文件夹下执行make命令即可，若编译成功，将会在该目录下生成对应的wasm文件，代码样例如下：

```
make
```

进入output目录下进行合约的部署，注意contract_name在实际敲写中需要换成相应的合约名字并填写合约的正确路径，代码样例如下：

```
./xchain-cli wasm deploy --account XC0123456789123456@xuper --cname contract_name -H 127.0.1.1:37105 -m ./contract_name.wasm --arg '{"creator":"xchain"}' --output tx_contract_name.out --runtime go --fee 10000
```

依据功能需求可进行合约相应方法的调用

- 车管所上传二手车信息代码样例如下：

```
./xchain-cli wasm invoke -a '{"VIN" :"LSGGA53WXBH292533","DMV_INFO" :{"Time" :1619616395,
"WheelBase" :"1.765","Manufacture" :1,"GearboxType" :1,"CarType" :1	,"EmissionStandard" :1,"MaxPs" :585,"TransferTime" :3,"MajorMalfunction" :true,"BubbleAndBurn" :false,"EngineNumber" :"35100-23701","DMVDescribe" :""}' --method UploadByDMV --fee 110000 contract_DMV
```

- 维修店上传二手车信息代码样例如下：

```
./xchain-cli wasm invoke -a '{"VIN" :"LSGGA53WXBH292533","RepairShop_INFO" :{"Mileage" :25.3,"PowerSunroof" :true,"PanoramicSunroof" :false,"GPS" :true,"ReversingRadar" :true,"ReversingImageSystem" :true,"LeatherSeat" :true,"SlightCollision" :false,"PaintRepairTime" :true,"SheetmetalRepairTime" :1,"AppearancePartsReplacementTime" :1,"RepairShopDescribe":""}' --method UploadByRepairShop --fee 110000 contract_RepairShop
```

- 保险公司上传二手车信息代码样例如下：

```
./xchain-cli wasm invoke -a '{"VIN" :"LSGGA53WXBH292533","InsuranceCompany_INFO" :{	"SellingPrice" :110000,"InsuranceCompanyDescribe":""}' --method UploadByInsuranceCompany --fee 110085 contract_InsuranceCompany
```

- 二手车成交价数据上传代码样例如下：

```
./xchain-cli wasm invoke -a '{"VIN" :"LSGGA53WXBH292533","LocalCompany_INFO" :{"SalePrice":11333333}' --method UploadByLocalCompany --fee 110000 contract_LocalCompany
```

- 根据VIN查询二手车信息代码样例如下：

```
./xchain-cli wasm invoke -a '{"VIN" :"LSGGA53WXBH292533"}' --method QueryCarByVIN --fee 110000 contract_enquery
```

- 查询各部门上传二手车数量代码样例如下：

```
./xchain-cli wasm invoke --method Statistics --fee 110000 contract_statistics
```

