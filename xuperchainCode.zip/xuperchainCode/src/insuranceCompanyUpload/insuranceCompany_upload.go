package main

import (
	"fmt"
	"strconv"
	"encoding/json"
	"github.com/xuperchain/xuperchain/core/contractsdk/go/code"
	"github.com/xuperchain/xuperchain/core/contractsdk/go/driver"
)

const InsuranceCompany, InsuranceCompanyCarCounts = "InsuranceCompany", "InsuranceCompanyCarCounts"

type CarStruct struct {
	SellingPrice float64		//报价
	InsuranceCompanyDescribe interface{}		//详细描述
}

type secondhand_car struct {}

func (e *secondhand_car) Initialize(ctx code.Context) code.Response {
	creator, ok := ctx.Args()["creator"]
	if !ok {
		return code.Errors("missing creator")
	}
	err := ctx.PutObject([]byte("creator"), creator)
	if err != nil {
		return code.Error(err)
	}
	initializeStatisticsData(ctx)
	return code.OK(nil)
}

func initializeStatisticsData(ctx code.Context) {
	ctx.PutObject([]byte(InsuranceCompanyCarCounts), []byte("0"))
}

func updateStatisticsData(ctx code.Context, key string) bool {
	value, err := ctx.GetObject([]byte(key))
	cnt := 0
	if err == nil {
		cnt, _ = strconv.Atoi(string(value))
	}

	var cntstr string

	cntstr = strconv.Itoa(cnt + 1)

	err = ctx.PutObject([]byte(key), []byte(cntstr))
	if err != nil {
		return false
	}
	return true
}

func upload(ctx code.Context, department string) code.Response {
	var key []byte
	var ok bool

	VIN, ok := ctx.Args()["VIN"]
	if !ok {
		return code.Errors("missing VIN")
	}

	if department == InsuranceCompany{
		b_value, ok := ctx.Args()["InsuranceCompany_INFO"]
		if !ok {
			return code.Errors("missing InsuranceCompany_INFO")
		}else{
			value := convert_json_to_map(b_value)
			if value["SellingPrice"] == nil{
				return code.Errors("missing SellingPrice")
			}else if value["InsuranceCompanyDescribe"] == nil{
				return code.Errors("missing InsuranceCompanyDescribe")
			}else{
				//car := &CarStruct{
				//	SellingPrice:value["SellingPrice"],
				//	InsuranceCompanyDescribe:value["InsuranceCompanyDescribe"],
				//}
				key = []byte("InsuranceCompany_" + string(VIN))
			}
		}
		err := ctx.PutObject(key, b_value)
		if err != nil {
			return code.Error(err)
		}
		updateStatisticsData(ctx, InsuranceCompanyCarCounts)
		return code.OK(b_value)
	}else{
		return code.Errors("the department is not insurance company.")
	}
}

// 保险公司数据上传
func (e *secondhand_car) UploadByInsuranceCompany(ctx code.Context) code.Response {
	return upload(ctx, InsuranceCompany)
}

func convert_json_to_map(b []byte)map[string]interface{}{
	var m map[string]interface{}
	err := json.Unmarshal(b, &m)
	if err != nil {
		fmt.Printf("unmarshal failed, err:%v\n", err)
		return nil
	}
	return m
}

func main() {
	driver.Serve(new(secondhand_car))
}

