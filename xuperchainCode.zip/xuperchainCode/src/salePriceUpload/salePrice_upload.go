package main

import (
	"fmt"
	"strconv"
	"encoding/json"
	"github.com/xuperchain/xuperchain/core/contractsdk/go/code"
	"github.com/xuperchain/xuperchain/core/contractsdk/go/driver"
)

const LocalCompany,SalePriceCarCounts = "LocalCompany", "SalePriceCarCounts"

type CarStruct struct {
	SalePrice	float64		//成交价
}

type secondhand_car struct {}

func (e *secondhand_car) Initialize(ctx code.Context) code.Response {
	creator, ok := ctx.Args()["creator"]
	if !ok {
		return code.Errors("missing creator")
	}
	err := ctx.PutObject([]byte("creator"), creator)
	if err != nil {
		return code.Error(err)
	}
	initializeStatisticsData(ctx)
	return code.OK(nil)
}


func initializeStatisticsData(ctx code.Context) {
	ctx.PutObject([]byte(SalePriceCarCounts), []byte("0"))
}

func updateStatisticsData(ctx code.Context, key string) bool {
	value, err := ctx.GetObject([]byte(key))
	cnt := 0
	if err == nil {
		cnt, _ = strconv.Atoi(string(value))
	}

	var cntstr string

	cntstr = strconv.Itoa(cnt + 1)

	err = ctx.PutObject([]byte(key), []byte(cntstr))
	if err != nil {
		return false
	}
	return true
}

func upload(ctx code.Context, department string) code.Response {
	var key []byte
	var ok bool

	VIN, ok := ctx.Args()["VIN"]
	if !ok {
		return code.Errors("missing VIN")
	}

	if department == LocalCompany{
		b_value, ok := ctx.Args()["LocalCompany_INFO"]
		if !ok {
			return code.Errors("missing LocalCompany_INFO")
		}else{
			value := convert_json_to_map(b_value)

			if value["SalePrice"] == nil{
				return code.Errors("missing SalePrice")
			}else{
				//car := &CarStruct{
				//	SalePrice: value["SalePrice"],
				//}
				key = []byte("LocalCompany_" + string(VIN))
			}
		}
		err := ctx.PutObject(key, b_value)
		if err != nil {
			return code.Error(err)
		}
		updateStatisticsData(ctx, SalePriceCarCounts)
		return code.OK(b_value)
	}else{
		return code.Errors("the department is not local company")
	}
}

// 本公司数据上传
func (e *secondhand_car) UploadByLocalCompany(ctx code.Context) code.Response {
	return upload(ctx, LocalCompany)
}

func convert_map_to_json(my_map map[string]interface{}) []byte{
	b, err := json.Marshal(my_map)
	if err != nil {
		fmt.Printf("marshal failed, err:%v\n", err)
	}
	return b
}

func convert_json_to_map(b []byte)map[string]interface{}{
	var m map[string]interface{}
	err := json.Unmarshal(b, &m)
	if err != nil {
		fmt.Printf("unmarshal failed, err:%v\n", err)
		return nil
	}
	return m
}

func main() {
	driver.Serve(new(secondhand_car))
}

