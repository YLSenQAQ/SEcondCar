package main

import (
	//"strconv"
	"encoding/json"
	"github.com/xuperchain/xuperchain/core/contractsdk/go/code"
	"github.com/xuperchain/xuperchain/core/contractsdk/go/driver"
)

const (
	AllCarCounts="AllCarCounts"
	DMVCarCounts="DMVCarCounts"
	RepairShopCarCounts="RepairShopCarCounts"
	InsuranceCompanyCarCounts="InsuranceCompanyCarCounts"
	SalePriceCarCounts="SalePriceCarCounts"
)

type secondhand_car struct {}

type StatisticsData struct {
	AllCarCounts string		// 已上传的车的数量
	DMVCarCounts string		// 车管所上传的车的数量
	RepairShopCarCounts string		// 维修店上传的车的数量
	InsuranceCompanyCarCounts string		// 保险公司上传的车的数量
	SalePriceCarCounts string		// 已上传车辆成交价的数量
}

func (e *secondhand_car) Initialize(ctx code.Context) code.Response {
	creator, ok := ctx.Args()["creator"]
	if !ok {
		return code.Errors("missing creator")
	}
	err := ctx.PutObject([]byte("creator"), creator)
	if err != nil {
		return code.Error(err)
	}

	return code.OK(nil)
}

// 统计数据：上传的车的数量
func (e *secondhand_car) Statistics(ctx code.Context) code.Response {
	statisticsData := &StatisticsData{
		DMVCarCounts: getByKey(ctx, DMVCarCounts),
		RepairShopCarCounts: getByKey(ctx, RepairShopCarCounts),
		InsuranceCompanyCarCounts: getByKey(ctx, InsuranceCompanyCarCounts),
		SalePriceCarCounts: getByKey(ctx, SalePriceCarCounts),
	}

	dataJson, _ := json.Marshal(statisticsData)

	return code.OK([]byte(dataJson))
}

func getByKey(ctx code.Context, key string) string {
	value, _ := ctx.GetObject([]byte(key))

	return string(value)
}

func main() {
	driver.Serve(new(secondhand_car))
}
